package com.garagze;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.garagze.database.GaragzeDbAdapter;

public class GaragzeApplication extends Application {
	
	private static GaragzeDbAdapter dbAdapter;

    private static Context context;

    @Override
    public void onCreate(){
    	Log.v("GaragzeApplication", "Creating application");
        GaragzeApplication.context = getApplicationContext();
        GaragzeApplication.dbAdapter = new GaragzeDbAdapter(context);
        GaragzeApplication.dbAdapter.open(); 
        // set language
    }

    public static Context getAppContext() {
    	return context;
    }

	public static GaragzeDbAdapter getDbAdapter() {
		return dbAdapter;
	}

}