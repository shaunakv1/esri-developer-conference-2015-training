package com.garagze;

import android.app.Activity;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.garagze.domain.Event;
import com.garagze.service.EventService;

public class AddEventActivity extends Activity {

	public static final String TAG = "AddEventActivity";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		Log.v(TAG, "Running onCreate");
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add_event);

		Log.v(TAG, "Declaring add button");
		final Button addButton = (Button) findViewById(R.id.add_button);

		addButton.getBackground().setColorFilter(getResources().getColor(R.color.actionbar_background_start),
				PorterDuff.Mode.MULTIPLY);

		addButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {

				final EditText streetView = (EditText) findViewById(R.id.event_street);
				String street = streetView.getText().toString();

				final EditText descriptionView = (EditText) findViewById(R.id.event_description);
				String description = descriptionView.getText().toString();

				Event event = new Event();
				event.setStreet(street);
				event.setDescription(description);
				event.setRating(3.0F);
				event.setCity("Naperville");

				EventService.addEvent(event);

				Log.v(TAG, "Running finish");
				finish();
			}
		});

		final Button cancelButton = (Button) findViewById(R.id.cancel_button);

		cancelButton.getBackground().setColorFilter(getResources().getColor(R.color.actionbar_background_start),
				PorterDuff.Mode.MULTIPLY);
		
		cancelButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View view) {

				Log.v(TAG, "Running finish");
				finish();
			}
		});

	}

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		Log.v(TAG, "Running onPostCreate");
		super.onPostCreate(savedInstanceState);
	}

	@Override
	protected void onStart() {
		Log.v(TAG, "Running onStart");
		super.onStart();
	}

	@Override
	protected void onRestart() {
		Log.v(TAG, "Running onRestart");
		super.onRestart();
	}

	@Override
	protected void onResume() {
		Log.v(TAG, "Running onResume");
		super.onResume();
	}

	@Override
	protected void onPostResume() {
		Log.v(TAG, "Running onPostResume");
		super.onPostResume();
	}

	@Override
	protected void onPause() {
		Log.v(TAG, "Running onPause");
		super.onPause();
	}

	@Override
	protected void onStop() {
		Log.v(TAG, "Running onStop");
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		Log.v(TAG, "Running onDestroy");
		super.onDestroy();
	}

}
