package com.garagze.feed;

import java.io.InputStream;

public interface XmlHttpRequest {
	
	public InputStream getUrlResponse(String urlString);

}
