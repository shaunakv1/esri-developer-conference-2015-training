package com.garagze.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class GaragzeDbHelper extends SQLiteOpenHelper {

	private static final String TAG = GaragzeDbHelper.class.getSimpleName();

	//@formatter:off
	private static final String DATABASE_CREATE = 
			  "create table events ("
			+ "_id integer primary key autoincrement, " 
			+ "id text, "
			+ "date date, " 
			+ "title text, " 
			+ "street text, " 
			+ "city text, "
			+ "state text, " 
			+ "zip text, " 
			+ "latitude double, "
			+ "longitude double, " 
			+ "description text, " 
			+ "rating double, "
			+ "distance double " 
			+ ");";
	//@formatter:on

	private static final String DATABASE_DROP = "drop table if exists events";

	@Override
	public void onCreate(SQLiteDatabase database) {
		Log.v(TAG, "Create Table using " + DATABASE_CREATE);
		database.execSQL(DATABASE_CREATE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase database, int oldVersion,
			int newVersion) {
		Log.v(TAG, "Drop Table, Upgrading from " + oldVersion + " to "
				+ newVersion);
		database.execSQL(DATABASE_DROP);
		onCreate(database);
	}

	public GaragzeDbHelper(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
	}

}
