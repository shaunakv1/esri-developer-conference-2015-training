package com.garagze.service;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.List;

import org.xmlpull.v1.XmlSerializer;

import android.content.Context;
import android.util.Log;
import android.util.Xml;

import com.garagze.GaragzeApplication;
import com.garagze.R;
import com.garagze.domain.Event;
import com.garagze.feed.EventXMLProcessor;
import com.garagze.feed.EventXMLProcessorAndroidSAX;

public class EventService {

	private static List<Event> events = null;

	private static final String TAG = "EventService";

	private static EventXMLProcessor parser = new EventXMLProcessorAndroidSAX();

	public static List<Event> getAllEvents(Context context) {
		if (events != null) {
			return events;
		} else {
			// Build events database
			InputStream inputStream = context.getResources().openRawResource(R.raw.naper_events);
			events = parser.processEventFeed(inputStream);
			for (Event event : events) {
				GaragzeApplication.getDbAdapter().insertEvent(event);
			}
			events = GaragzeApplication.getDbAdapter().getAllEvents();
		}
		
		return events;
	}

	public static void addEvent(Event event) {
		Log.v(TAG, "Running addEvent: " + event.getTitle());
		Log.v(TAG, "Number of events before add:" + events.size());
		events.add(0, event);
		GaragzeApplication.getDbAdapter().insertEvent(event);

		// assign event id
		event.setId(java.util.UUID.randomUUID().toString());
		event.setDate(new java.util.Date());

		// write to file
		writeFile(event.getId() + ".txt", writeXml(event));
	}

	public static String writeXml(Event event) {
		XmlSerializer serializer = Xml.newSerializer();
		StringWriter writer = new StringWriter();
		try {
			serializer.setOutput(writer);
			serializer.startDocument("UTF-8", true);
			serializer.startTag("", "events");

			serializer.startTag("", "event");

			serializeTag(serializer, "id", event.getId());
			serializeTag(serializer, "date", event.getDate().toLocaleString());
			serializeTag(serializer, "title", event.getTitle());
			serializeTag(serializer, "street", event.getStreet());
			serializeTag(serializer, "city", event.getCity());
			serializeTag(serializer, "state", event.getState());
			serializeTag(serializer, "zip", event.getZip());
			serializeTag(serializer, "latitude", Double.toString(event.getLatitude()));
			serializeTag(serializer, "longitude", Double.toString(event.getLongitude()));
			serializeTag(serializer, "rating", Float.toString(event.getRating()));
			serializeTag(serializer, "description", event.getDescription());

			serializer.endTag("", "event");

			serializer.endTag("", "events");
			serializer.endDocument();
			return writer.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static void serializeTag(XmlSerializer serializer, String tagName, String tagValue) throws IOException {
		serializer.startTag("", tagName);
		if (tagValue != null) {
			serializer.text(tagValue);
		}
		serializer.endTag("", tagName);
	}

	public static void writeFile(String fileName, String output) {
		FileOutputStream fos = null;
		try {
			// note that there are many modes you can use
			fos = GaragzeApplication.getAppContext().openFileOutput(fileName, Context.MODE_PRIVATE);
			fos.write(output.getBytes());
			Log.v("EventService", "File written: " + fileName);
		} catch (FileNotFoundException e) {
			Log.e("EventService", "File not found", e);
			e.printStackTrace();
		} catch (IOException e) {
			Log.e("EventService", "IO problem", e);
			e.printStackTrace();
		} finally {
			try {
				fos.close();
			} catch (IOException e) {
				Log.e("EventService", "IO problem", e);
				e.printStackTrace();
			}
		}
	}
}
